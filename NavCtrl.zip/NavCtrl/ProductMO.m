//
//  ProductMO.m
//  NavCtrl
//
//  Created by Chad Wiedemann on 9/1/16.
//  Copyright © 2016 Aditya Narayan. All rights reserved.
//

#import "ProductMO.h"
#import "CompanyMO.h"

@implementation ProductMO

// Insert code here to add functionality to your managed object subclass

@end
