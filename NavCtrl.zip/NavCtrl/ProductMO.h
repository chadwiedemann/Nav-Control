//
//  ProductMO.h
//  NavCtrl
//
//  Created by Chad Wiedemann on 9/1/16.
//  Copyright © 2016 Aditya Narayan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class CompanyMO;

NS_ASSUME_NONNULL_BEGIN

@interface ProductMO : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "ProductMO+CoreDataProperties.h"
