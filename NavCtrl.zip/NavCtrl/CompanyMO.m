//
//  CompanyMO.m
//  NavCtrl
//
//  Created by Chad Wiedemann on 9/1/16.
//  Copyright © 2016 Aditya Narayan. All rights reserved.
//

#import "CompanyMO.h"
#import "ProductMO.h"

@implementation CompanyMO

// Insert code here to add functionality to your managed object subclass

@end
